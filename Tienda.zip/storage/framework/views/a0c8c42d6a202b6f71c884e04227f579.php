<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">

    <!-- Scripts -->
    

    <style>
        .navbar {
            background: #e9183b;
        }
    </style>
</head>

<body>
    <div class="containeer">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="/home" style="color: white"><img src="/assets/img/favicon.ico"
                    width="50"> Rines
                Saucedo</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ml-auto">
                    <?php $__currentLoopData = Menu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($Me->submenu == 1): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                    role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                    style="color: white">
                                    <?php echo e($Me->nombre); ?></a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <?php $__currentLoopData = submenu($Me->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" href="<?php echo e($submenu->url); ?>"><?php echo e($submenu->nombre); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e($Me->url); ?>" role="button" aria-haspopup="true"
                                    aria-expanded="false" style="color: white">
                                    <?php echo e($Me->nombre); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <form id="logout-form" action="/logout" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-warning"><i class="typcn typcn-power-outline"></i>
                            <?php echo e(__('Salir')); ?></button>
                    </form>
                </ul>
            </div>
        </nav>

        <?php if(session('success')): ?>
            <div class="alert alert-success" id="success-alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>


        <?php echo $__env->yieldContent('content'); ?>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

    <script>
        setTimeout(function() {
            const successAlert = document.getElementById('success-alert');
            if (successAlert) {
                successAlert.style.display = 'none';
            }
        }, 5000);
    </script>
</body>

</html>
<?php /**PATH D:\Escuela\Nueva carpeta\TiendaDimas\Tienda\resources\views/layouts/app.blade.php ENDPATH**/ ?>