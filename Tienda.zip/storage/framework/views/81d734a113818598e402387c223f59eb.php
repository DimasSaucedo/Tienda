<?php $__env->startSection('content'); ?>
    <style>

    </style>
    <div class="container mt-4">
        <h2 class="mb-4">Llantas de Potreros</h2>

        <div class="table-responsive">
            <div>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-agregar">Agregar nueva
                    llanta</button>
            </div>
            <br>
            <table id="example" class="table table-striped table-bordered table-hover" style="width:100%">
                <thead style="background: #e9183b; color: white">
                    <tr>
                        <th class="text-center" style="width: 10px">Cantidad</th>
                        <th class="text-center" style="width: 10px">Letra</th>
                        <th class="text-center">Medida</th>
                        <th class="text-center">Marca</th>
                        <th class="text-center" style="width: 100px">Precio Compra</th>
                        <th class="text-center" style="width: 100px">Precio Venta</th>
                        <th class="text-center">Opciones</th>
                    </tr>
                </thead>
                <tbody style="background: white">
                    <?php $__currentLoopData = $llantas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="width: 10px"><?php echo e($ll->Cantidad); ?></td>
                            <td class="text-center" style="width: 10px"><?php echo e($ll->Letra); ?></td>
                            <td><?php echo e($ll->Medida); ?></td>
                            <td><?php echo e($ll->Marca); ?></td>
                            <td class="text-center" style="width: 80px"><?php echo e(formatearNumero($ll->PrecioCompra)); ?></td>
                            <td class="text-center" style="width: 80px"><?php echo e(formatearNumero($ll->PrecioVenta)); ?></td>
                            <td class="text-center">
                                <div class="d-flex">
                                    <button type="button" class="btn btn-success mr-2" style="width: 100px"
                                        data-toggle="modal"
                                        data-target="#modal-actualizar-<?php echo e($ll->id); ?>">Actualizar</button>

                                    <form action="/eliminar_llantap" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input hidden value="<?php echo e($ll->id); ?>" name="id" id="id">
                                        <button type="submit" class="btn btn-danger" style="width: 100px">Eliminar</button>
                                    </form>
                                </div>

                            </td>
                        </tr>
                        <?php echo $__env->make('Poteros.actualizarLlantaP', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $__env->make('Poteros.agregarLlanta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <br>
    <br>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                responsive: true,
                dom: 'Blfrtip',
                stateSave: false,
                language: {
                    "url": "/assets/lib/datatable/es.json"
                },
                paging: false,
                ordering: false

            });

            document.getElementById('agregarLlantaForm').addEventListener('submit', function(event) {
                const fields = document.querySelectorAll('#agregarLlantaForm input[required]');
                let allFilled = true;
                fields.forEach(function(field) {
                    if (!field.value) {
                        allFilled = false;
                        field.classList.add('is-invalid');
                    } else {
                        field.classList.remove('is-invalid');
                    }
                });

                if (!allFilled) {
                    event.preventDefault();
                    alert('Por favor, complete todos los campos.');
                }
            });

            document.getElementById('marca').addEventListener('input', function() {
                this.value = this.value.toUpperCase();
            });
            document.getElementById('letra').addEventListener('input', function() {
                this.value = this.value.toUpperCase();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Escuela\Nueva carpeta\TiendaDimas\Tienda\resources\views/Poteros/llantas.blade.php ENDPATH**/ ?>