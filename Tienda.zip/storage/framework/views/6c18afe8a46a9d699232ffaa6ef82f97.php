<?php $__env->startSection('content'); ?>
    <style>
        .containeer {
            background: url('/assets/img/fondo.jpg') no-repeat center center;
            background-size: cover;
            min-height: 100vh;
        }

        
    </style>
    <div class="container">

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Escuela\Nueva carpeta\TiendaDimas\Tienda\resources\views/home.blade.php ENDPATH**/ ?>