<div>
    <!-- Life is available only in the present moment. - Thich Nhat Hanh -->
</div>
<?php /**PATH D:\Escuela\Nueva carpeta\TiendaDimas\Tienda\resources\views/Guadalupano/agregarLlanta.blade.php ENDPATH**/ ?>