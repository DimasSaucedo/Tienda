<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2 class="mb-4"> Baterias del Guadalupano</h2>

        <div class="table-responsive">
            <div>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-agregar">Agregar nueva
                    bateria</button>
            </div>
            <br>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead style="background: #e9183b; color: white">
                    <tr>
                        <th class="text-center" style="width: 10px">Cantidad</th>
                        <th class="text-center" style="width: 10px">No. Bateria</th>
                        <th class="text-center">Marca</th>
                        <th class="text-center" style="width: 100px">Precio Compra</th>
                        <th class="text-center" style="width: 100px">Precio Venta</th>
                        <th class="text-center">Opciones</th>
                    </tr>
                </thead>
                <tbody style="background: white">
                    <?php $__currentLoopData = $baterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="width: 10px"><?php echo e($ll->Cantidad); ?></td>
                            <td class="text-center" style="width: 10px"><?php echo e($ll->NoBateria); ?></td>
                            <td class="text-center"><?php echo e($ll->Marca); ?></td>
                            <td class="text-center" style="width: 100px"><?php echo e($ll->PrecioCompra); ?></td>
                            <td class="text-center" style="width: 100px"><?php echo e($ll->PrecioVenta); ?></td>
                            <td class="text-center">
                                <button type="button" class="btn btn-success" style="width: 100px" data-toggle="modal"
                                    data-target="#modal-actualizar-<?php echo e($ll->id); ?>">Actualizar</button>
                                <br><br>
                                <form action="/eliminar_bateriag" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input hidden value="<?php echo e($ll->id); ?>" name="id" id="id">
                                    <button type="submit" class="btn btn-danger" style="width: 100px">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                        <?php echo $__env->make('Guadalupano.actualizarBateriaG', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $__env->make('Guadalupano.agregarBateria', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                responsive: true,
                dom: 'Blfrtip',
                stateSave: true,
            });

            document.getElementById('agregarLlantaForm').addEventListener('submit', function(event) {
                const fields = document.querySelectorAll('#agregarLlantaForm input[required]');
                let allFilled = true;
                fields.forEach(function(field) {
                    if (!field.value) {
                        allFilled = false;
                        field.classList.add('is-invalid');
                    } else {
                        field.classList.remove('is-invalid');
                    }
                });

                if (!allFilled) {
                    event.preventDefault();
                    alert('Por favor, complete todos los campos.');
                }
            });

            document.getElementById('marca').addEventListener('input', function() {
                this.value = this.value.toUpperCase();
            });
            document.getElementById('letra').addEventListener('input', function() {
                this.value = this.value.toUpperCase();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Escuela\Nueva carpeta\TiendaDimas\Tienda\resources\views/Guadalupano/baterias.blade.php ENDPATH**/ ?>