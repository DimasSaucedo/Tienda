<div>
    <!-- Very little is needed to make a happy life. - Marcus Aurelius -->
</div>
<?php /**PATH D:\Escuela\Nueva carpeta\TiendaDimas\Tienda\resources\views/Guadalupano/actualizarLlantaP.blade.php ENDPATH**/ ?>